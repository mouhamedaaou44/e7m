module.exports.config = {
	name: "العدالة",
	version: "1.0.0",
	hasPermssion: 2,
	credits: "Your Name",
	description: "Reset all members' money in the group",
	commandCategory: "economy",
	usages: "",
	cooldowns: 5
};

module.exports.run = async function({ api, event, Currencies }) {
	const { threadID } = event;
	let members = await api.getThreadInfo(threadID).then(info => info.participantIDs);
	members.forEach(async (userID) => {
		await Currencies.setData(userID, { money: 0 });
	});
	return api.sendMessage("ليكون الأمر عادلا بين الجميع تم اعادة المال من الصفر اذا اردت مالا اجمعه بنفسك 🖕🏼🖕🏼🖕🏼🖕🏼.", threadID);
}